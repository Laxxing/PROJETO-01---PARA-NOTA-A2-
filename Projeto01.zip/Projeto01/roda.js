import chalk from 'chalk';
import fs from 'fs';

function trataErro(erro){
    throw new Error(chalk.red(erro.code, "Não há arquivos no caminho"));
}

async function leArquivo(caminhoArquivo){
    const endcoding = 'utf-8';
    const texto = await fs.promises.readFile(caminhoArquivo, endcoding)
    console.log(chalk.green(texto))
    }

export default leArquivo;